﻿<####################################################################################################
SolidSCP - Simple server setup menu

v1.0    24th May 2016:    First release of the SolidCP Install Script

Written By Marc Banyard for the SolidCP Project (c) 2016 SolidCP

All Code provided as is and used at your own risk.
####################################################################################################>

# Editable features are below this line

$InstallSNMPchk = $true # Enable or disable by $true|$false
$SNMPsysContact  = ""   # SNMP Contact Name
$SNMPsysLocation = ""   # SNMP Server Location
$dMsSQLpassword  = ""   # Enter the password for your MS SQL "sa" User
$dMySQLpassword  = ""   # Enter the password for your MySQL "root" User


# Editable features are above this line
####################################################################################################
#
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
#
# DO NOT EDIT ANYTHING BELOW THIS LINE
#
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
####################################################################################################
# Main menu starts here
Function SolidCPmenu() {
	do {
		do {
		cls
			Write-Host "`n`tSolidCP Setup Menu`n" -ForegroundColor Magenta
			Write-Host "`t`tPlease select the type of server you are installing SolidCP onto`n" -Fore Cyan
	$menu = @"
			1. SolidCP Exterprise Server / Portal
			2. Microsoft DNS Server
			3. Microsoft Web Server - Automated (IIS, FTP, PHP, PHP Manager, Python, Perl, MySQL, MS SQL)
			4. Microsoft Web Server - Prompted
			5. AwStats
			6. Active Directory (Domain Controllers)
			7. Microsoft Exchange (CAS Server Role)
			8. Microsoft Exchange (Mailbox Server Role)
			9. Microsoft Exchange (File Share Witness - DAG ONLY)
			0. Microsoft Remote Desktop Services - Host Server
			A. Microsoft Remote Desktop Services - Licencing Server

		We also have the following tools to help with the above

			W. Microsoft Exchange - Fix Failed Database Content Indexes

			X. Quit and exit
"@
	$menuOptions = '^[0-9aw-x]+$'

			Write-Host $menu -Fore Cyan
			$choice = Read-Host "`n`tEnter Option From Above Menu"
			$ok = $choice -match $menuOptions
		
			if ( -not $ok) { Write-Host "Invalid selection" ; start-Sleep -Seconds 2 }
		} until ( $ok )
		
		switch -Regex ( $choice ) {
			"1" {CLS
				 Write-Host "`nInstalling the required windows features for the 'SolidCP Enterprise Server and Portal'" -ForegroundColor Magenta
				 Function dSolidCPesPortal() { # Function to call multiple functions to install SolidCP Enterprise Server and Portal
					if ( (!$dMsSQLpassword) -and (!$dMySQLpassword) ) {
						Write-Host "`t*****************************************************************************" -ForegroundColor Red
						Write-Host "`t*                                                                           *" -ForegroundColor Red
						Write-Host "`t*                         YOUR ATTENTION IS REQUIRED!                       *" -ForegroundColor Red
						Write-Host "`t*                                                                           *" -ForegroundColor Red
						Write-Host "`t*              Please enter the passwords you would like to use             *" -ForegroundColor Red
						Write-Host "`t*            on Microsft SQL Server (with Tools) and MySQL Server           *" -ForegroundColor Red
						Write-Host "`t*                               when prompted                               *" -ForegroundColor Red
						Write-Host "`t*                                                                           *" -ForegroundColor Red
						Write-Host "`t*****************************************************************************`n`n" -ForegroundColor Red
					}else{
						Write-Host "`n`n`n`n`n`n`n`n"
					}
					if (!$dMsSQLpassword) {
						$responseMsSQL = Read-host "`nEnter the SA password you want to use for your Microsoft SQL Server" -AsSecureString
						$dMsSQLpassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($responseMsSQL)) ; $dSQLpasswordEntered = "1"
					}
					if ($dSQLpasswordEntered) {
						dCheckSQLpasswords
					}
					Write-Host "`tStarting server setup for SolidCP`n" -ForegroundColor Red
					dEnableWindowsUpdates
					InstallCommonFeatures
					InstallIISforSolidCP
					InstallIISforESandPortal
					HardenDotNETforIIS
					FixServer2012UAC
					InstallSQLsvr2014withTools $dMsSQLpassword
					InstallMSSQL_TCPports
					InstallFirewall_MSSQL
					InstallDisablePasswdComplex
					InstallSOlidCPInstaller
				 }
				 dInstallConfirm "SolidCP Enterprise Server and Portal Requirements" $function:dSolidCPesPortal		# Install the SolidCP ES and Portal if user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}
		
			"2" {CLS
				 Write-Host "Installing the required windows features for a 'Microsoft DNS Server'" -ForegroundColor Magenta
				 Function dSolidCPdnsServer() { # Function to call multiple functions to install Features for Microsoft DNS Server
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					dEnableWindowsUpdates
					InstallCommonFeatures
					InstallIISforSolidCP
					InstallDNSServer
					HardenDotNETforIIS
					FixServer2012UAC
					InstallDisablePasswdComplex
					InstallSOlidCPInstaller
				 }
				 dInstallConfirm "SolidCP Enterprise Server and Portal Requirements" $function:dSolidCPdnsServer	# Install the Microsft DNS Server if the user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"3" {CLS
				 Write-Host "Installing the required windows features for a 'Microsoft Web Server' (IIS, FTP, PHP, Python, Perl, MySQL and MS SQL" -ForegroundColor Magenta
				 Function dSolidCPwebServer() { # Function to call multiple functions to install Features for IIS, FTP, PHP, Python, Perl, MySQL and MS SQL
					if ( (!$dMsSQLpassword) -and (!$dMySQLpassword) ) {
						Write-Host "`t*****************************************************************************" -ForegroundColor Red
						Write-Host "`t*                                                                           *" -ForegroundColor Red
						Write-Host "`t*                         YOUR ATTENTION IS REQUIRED!                       *" -ForegroundColor Red
						Write-Host "`t*                                                                           *" -ForegroundColor Red
						Write-Host "`t*              Please enter the passwords you would like to use             *" -ForegroundColor Red
						Write-Host "`t*            on Microsft SQL Server (with Tools) and MySQL Server           *" -ForegroundColor Red
						Write-Host "`t*                               when prompted                               *" -ForegroundColor Red
						Write-Host "`t*                                                                           *" -ForegroundColor Red
						Write-Host "`t*****************************************************************************`n`n" -ForegroundColor Red
					}else{
						Write-Host "`n`n`n`n`n`n`n`n"
					}
					if (!$dMsSQLpassword) {
						$responseMsSQL = Read-host "`nEnter the SA password you want to use for your Microsoft SQL Server" -AsSecureString
						$dMsSQLpassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($responseMsSQL)) ; $dSQLpasswordEntered = "1"
					}
					if (!$dMySQLpassword) {
						$responseMySQL = Read-host "`nEnter the ROOT password you want to use for your MySQL Server" -AsSecureString
						$dMySQLpassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($responseMySQL)) ; $dSQLpasswordEntered = "1"
					}
					if ($dSQLpasswordEntered) {
						dCheckSQLpasswords
					}
					Write-Host "`tStarting server setup for SolidCP`n" -ForegroundColor Red
					dEnableWindowsUpdates
					InstallCommonFeatures
					InstallIISforSolidCP
					InstallIISforHosting
					HardenDotNETforIIS
					FixServer2012UAC
					InstallFTPforHosting
					InstallWebPI
					InstallWebPI_PHP
					InstallWebPI_Python
					InstallWebPI_SQLdriverPHP
					InstallWebPI_URLreWrite
					InstallWebPI_WebDeploy
					InstallActivePerl
					InstallWebPI_MySQL $dMySQLpassword
					InstallFirewall_MySQL
					InstallSQLsvr2014withTools $dMsSQLpassword
					InstallSQLsvr2012NativeClnt
					InstallMSSQL_TCPports
					InstallFirewall_MSSQL
					InstallDisablePasswdComplex
					InstallSOlidCPInstaller
				 }
				 dInstallConfirm "IIS, FTP, PHP, Python, Perl, MySQL and MS SQL `(with Tools`)" $function:dSolidCPwebServer		# Install IIS, FTP, PHP, Python, Perl, MySQL and MS SQL if the user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"4" {CLS
				 Write-Host "Installing the required windows features for a 'Microsoft Web Server - Prompted'" -ForegroundColor Magenta
				 Function dSolidCPwebServerPrompt() { # Function to call multiple functions to install Features for IIS, FTP, PHP, Python, Perl, MySQL and MS SQL
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					dEnableWindowsUpdates
					InstallCommonFeatures
					InstallIISforSolidCP
					InstallIISforHosting
					HardenDotNETforIIS
					FixServer2012UAC
					InstallWebPI
					dInstallConfirm "Microsoft FTP Server" $function:InstallFTPforHosting							# Prompt to install Microsoft FTP Server
					dInstallConfirm "PHP for IIS" $function:InstallWebPI_PHP										# Prompt to install PHP for IIS
					dInstallConfirm "Python v3.4" $function:InstallWebPI_Python										# Prompt to install Python v3.4
					dInstallConfirm "SQL Server Driver for PHP" $function:InstallWebPI_SQLdriverPHP					# Prompt to install SQL Server Driver for PHP
					dInstallConfirm "URL Rewrite Module" $function:InstallWebPI_URLreWrite							# Prompt to install URL Rewrite Module
					dInstallConfirm "Web Deploy module" $function:InstallWebPI_WebDeploy							# Prompt to install Web Deploy Module
					dInstallConfirm "Active Perl v5.22.1" $function:InstallActivePerl								# Prompt to install Active Perl v5.22.1
					dInstallConfirm "MySQL Database Server" $function:InstallWebPI_MySQL							# Prompt to install MySQL Database Server
					dInstallConfirm "MySQL Firewall Rule" $function:InstallFirewall_MySQL							# Prompt to install MySQL Firewall Rule
					dInstallConfirm "Microsoft SQL Server 2014 Express" $function:InstallSQLsvr2014noTools			# Prompt to install Microsoft SQL Server 2014 Express
					dInstallConfirm "SQL Server 2014 Management Tools" $function:InstallSQLsvr2014mgmtTools			# Prompt to install Microsoft SQL Server 2014 Express Management Tools
					dInstallConfirm "Microsoft SQL Server 2012 Native Client" $function:InstallSQLsvr2012NativeClnt	# Prompt to install Microsoft SQL Server 2012 Native Client
					dInstallConfirm "Open SQL Server TCP Ports" $function:InstallMSSQL_TCPports						# Prompt to enable Microsoft SQL Server TCP Ports and Named Pipes
					dInstallConfirm "Microsoft SQL Server Firewall Rule" $function:InstallFirewall_MSSQL			# Prompt to install Microsoft SQL Server Firewall Rules
					dInstallConfirm "Disable Password Complexity (Local)" $function:InstallDisablePasswdComplex		# Prompt to disable local password complexity
					dInstallConfirm "SolidCP Installer Application" $function:InstallSOlidCPInstaller				# Prompt to download and install the SOlidCP Installation Application
				 }
				 dInstallConfirm "Microsoft IIS Server with prompts" $function:dSolidCPwebServerPrompt				# Install IIS if the user agrees (seperate prompts will be asked for the above components)
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"5" {CLS
				 Write-Host "Installing the required windows features for the 'AwStats Server'" -ForegroundColor Magenta
				 Function dSolidCPawStats() { # Function to call multiple functions to install AwStats
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					InstallCommonFeatures
					InstallIISforSolidCP
					InstallAwStats
					HardenDotNETforIIS
					FixServer2012UAC
					InstallWebPI
					InstallWebPI_PHP
					InstallWebPI_Python
					InstallActivePerl
					InstallDisablePasswdComplex
					InstallSOlidCPInstaller
				 }
				 dInstallConfirm "AwStats Server" $function:dSolidCPawStats		# Install the AwStats if user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"6" {CLS
				 Write-Host "Installing the required windows features for 'Microsoft Active Directory (Domain Controllers)'" -ForegroundColor Magenta
				 Function dSolidCPActiveDirectory() { # Function to call multiple functions to install Active Directory Requirements
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					InstallCommonFeatures
					InstallActiveDirectory
				 }
				 dInstallConfirm "Microsoft Active Directory Requirements" $function:dSolidCPActiveDirectory		# Install the Active Directory Requirements if user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"7" {CLS
				 Write-Host "Installing the required windows features for 'Microsoft Exchange (CAS Server Role)'" -ForegroundColor Magenta
				 Function dSolidCPexchangeCAS() { # Function to call multiple functions to install Microsoft Exchange CAS Role Requirements
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					InstallCommonFeatures
					InstallIISforSolidCP
					InstallExchangeCAS
				 }
				 dInstallConfirm "Microsoft Exchange `(CAS Role`) Requirements" $function:dSolidCPexchangeCAS		# Install the Microsoft Exchange CAS Role Requirements if user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"8" {CLS
				 Write-Host "Installing the required windows features for 'Microsoft Exchange (Mailbox Server Role)'" -ForegroundColor Magenta
				 Function dSolidCPexchangeMBX() { # Function to call multiple functions to install Microsoft Exchange Mailbox Role Requirements
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					InstallCommonFeatures
					InstallIISforSolidCP
					InstallExchangeMBX
				 }
				 dInstallConfirm "Microsoft Exchange `(Mailbox Role`) Requirements" $function:dSolidCPexchangeMBX	# Install the Microsoft Exchange Mailbox Role Requirements if user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"9" {CLS
				 Write-Host "Installing the required windows features for 'Microsoft Exchange (File Share Witness - DAG ONLY)'" -ForegroundColor Magenta
				 Function dSolidCPexchangeMBX() { # Function to call multiple functions to install Microsoft Exchange File Share Witness - DAG ONLY Role Requirements
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					InstallCommonFeatures
					InstallExchangeFSW
				 }
				 dInstallConfirm "Microsoft Exchange `(File Share Witness - DAG ONLY`) Requirements" $function:dSolidCPexchangeMBX	# Install the Microsoft Exchange Mailbox Role Requirements if user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"0" {CLS
				 Write-Host "Installing the required windows features for 'Microsoft Remote Desktop Services - Host Server'" -ForegroundColor Magenta
				 Function dSolidCP_RDShostSvr() { # Function to call multiple functions to install Microsoft Remote Desktop Services Host Server Requirements
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					InstallCommonFeatures
					InstallRDShostServer
					InstallSQLsvr2012NativeClnt
					HardenDotNETforIIS
					FixServer2012UAC
				 }
				 dInstallConfirm "Microsoft RDS (Host Server) Requirements" $function:dSolidCP_RDShostSvr			# Install the Microsoft RDS Host Server Requirements if user agrees
				 dPressAnyKeyToExit
				 $choice = "x"
			}
	
			"A" {CLS
				 Write-Host "Installing the required windows features for 'Microsoft Remote Desktop Services - Licencing Server'" -ForegroundColor Magenta
				 Function dSolidCP_RDSlicencingSvr() { # Function to call multiple functions to install Microsoft Remote Desktop Services Licencing Server Requirements
					Write-Host "`t*****************************************************************************" -ForegroundColor Red
					Write-Host "`t*                                                                           *" -ForegroundColor Red
					Write-Host "`t*                         YOUR ATTENTION IS REQUIRED!                       *" -ForegroundColor Red
					Write-Host "`t*                                                                           *" -ForegroundColor Red
					Write-Host "`t*              Please enter the passwords you would like to use             *" -ForegroundColor Red
					Write-Host "`t*                    on Microsft SQL Server (with Tools)                    *" -ForegroundColor Red
					Write-Host "`t*                               when prompted                               *" -ForegroundColor Red
					Write-Host "`t*                                                                           *" -ForegroundColor Red
					Write-Host "`t*****************************************************************************`n`n" -ForegroundColor Red
					$responseMsSQL = Read-host "`nEnter the SA password you want to use for your Microsoft SQL Server" -AsSecureString
					$dMsSQLpassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($responseMsSQL))
					Write-Host "`n`n`n`n`n`n`n`n`tStarting server setup for SolidCP`n" -ForegroundColor Red
					InstallCommonFeatures
					InstallSQLsvr2014withTools $dMsSQLpassword
					InstallSQLsvr2012NativeClnt
					InstallMSSQL_TCPports
					InstallFirewall_MSSQL
					HardenDotNETforIIS
					FixServer2012UAC
				 }
				 dInstallConfirm "Microsoft RDS `(Licencing Server`) Requirements" $function:dSolidCP_RDSlicencingSvr	# Install the Microsoft RDS Licencing Server Requirements if user agrees
				 $choice = "x"
			}

			"W" {CLS
				 Write-Host "Microsoft Exchange - Fixing the Failed Database Content Indexes" -ForegroundColor Magenta
				 Write-Host "Nothing done, this will be added soon" -ForegroundColor Green ; start-Sleep -Seconds 2
				 dPressAnyKeyToExit
				 $choice = "x"
			}

			"X" {CLS
				 Write-Host "`t ******************************" -ForegroundColor Green
				 Write-Host "`t *                            *" -ForegroundColor Green
				 Write-Host "`t *          Quitting          *" -ForegroundColor Green
				 Write-Host "`t *                            *" -ForegroundColor Green
				 Write-Host "`t *    NO Changes were made    *" -ForegroundColor Green
				 Write-Host "`t *                            *" -ForegroundColor Green
				 Write-Host "`t ******************************" -ForegroundColor Green
				 start-Sleep -Seconds 2
				 dPressAnyKeyToExit
			}
		}
	} until ( $choice -match "X" )
}
# Main menu end

########################################################################################################################################################################################################
# Functions start below here #
##############################


####################################################################################################################################################################################
Function dInstallConfirm($dInstallName, $sFunctionToRun)	# Function to prompt for confirmation to install application called from a function
{ # Usage - dInstallConfirm "SQL Server" $function:dTestScript
	CLS
	$choice = ""
	while ($choice -notmatch "[y|n]") { CLS ; $choice = read-host "`n Do you want to install $dInstallName`? (Y/N)" }
	if ($choice -eq "y") {
		$($sFunctionToRun.Invoke())
		Write-Host "`n`t$dInstallName has been installed" -ForegroundColor Green ; start-Sleep -Seconds 2
	} else {
		write-host "`n`t$dInstallName installation cancelled by user" -ForegroundColor Red    ; start-Sleep -Seconds 2
	}
 }


####################################################################################################################################################################################
Function dCheckSQLpasswords()								# Function to prompt for confirmation to view the passwords for SQL Server that have just been entered
{
	$choiceCheckSQLpasswords = ""
	while ($choiceCheckSQLpasswords -notmatch "[y|n]") { CLS ; $choiceCheckSQLpasswords = read-host "`n Do you want to view the SQL passwords you have just entered? (Y/N)" }
	if ($choiceCheckSQLpasswords -eq "y") {
		Write-Host "`n The MS SQL Password entered was - $dMsSQLpassword" -ForegroundColor Green
		Write-Host "`n The MySQL Password entered was - $dMySQLpassword" -ForegroundColor Green
		dPressAnyKeyToContinue
		CLS
	}
 }


####################################################################################################################################################################################
Function dEnableWindowsUpdates()							# Function to enable windows updates on the machine
{
	Write-Host "`tEnabling Windows Updates on this machine" -ForegroundColor Cyan
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name IsOOBEInProgress -value 0 -Type DWord
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name AUOptions -value 2 -Type DWord
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name IncludeRecommendedUpdates -value 1 -Type DWord
#	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name NonFirmwareUpdatesAvailableForInstall -value 0 -Type DWord
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name CachedAUOptions -value 2 -Type DWord
#	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name InstallInProgress -value 0 -Type DWord
#	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name UpdatesAvailableForDownloadLogon -value 0 -Type DWord
#	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name UpdatesAvailableForInstallLogon -value 0 -Type DWord
#	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name UpdatesAvailableWithUiOrEulaLogon -value 0 -Type DWord
#	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name UpdatesAvailableWithUiLogon -value 0 -Type DWord
#	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name FirmwareUpdatesNotDownloaded -value 0 -Type DWord
#	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name FirmwareUpdatesNotInstalled -value 0 -Type DWord
#	if (!(Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RequestedAppCategories")) {
#		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RequestedAppCategories" -ItemType Key
#	}
#	if (!(Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RequestedAppCategories\9482f4b4-e343-43b6-b170-9a65bc822c77")) {
#		New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RequestedAppCategories\9482f4b4-e343-43b6-b170-9a65bc822c77" -ItemType Key
#	}
	(new-object -c "microsoft.update.servicemanager").addservice2("7971f918-a847-4430-9279-4a52d1efe18d",7,"") | Out-Null
	invoke-command{net stop wuauserv} | Out-Null
	invoke-command{net start wuauserv} | Out-Null
}


####################################################################################################################################################################################
Function dPressAnyKeyToExit()								# Function to press any key to exit
{
	if ($psISE) { # Check if running Powershell ISE
		Add-Type -AssemblyName System.Windows.Forms
		[System.Windows.Forms.MessageBox]::Show("Press any key to exit")
	}else{
		Write-Host "`n`tPress any key to exit..." -ForegroundColor Yellow
		$x = $host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown")
	}
}


####################################################################################################################################################################################
Function dPressAnyKeyToContinue()								# Function to press any key to exit
{
	if ($psISE) { # Check if running Powershell ISE
		Add-Type -AssemblyName System.Windows.Forms
		[System.Windows.Forms.MessageBox]::Show("Press any key to continue")
	}else{
		Write-Host "`n`tPress any key to continue..." -ForegroundColor Yellow
		$x = $host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown")
	}
}


####################################################################################################################################################################################
Function InstallCommonFeatures()		# Function for common features on the servers
{
	Write-Host "`tInstalling the common features required for SolidCP" -ForegroundColor Cyan
	(Import-Module ServerManager) | Out-Null
	# Install .NET Framework 3.5 on the server
	(Add-WindowsFeature -Name Net-Framework-Core) | Out-Null
	# Install PowerShell (current) as well as the older v2 for compatability
	(Add-WindowsFeature -Name PowerShell, PowerShell-V2) | Out-Null
	# Install SNMP and configure it on this machine as long as the $InstallSNMPchk is set as true
	if ($InstallSNMPchk) {
		# Install and Configure SNMP on the server so we can monitor it
		(Add-WindowsFeature -Name SNMP-Service -IncludeAllSubFeature -IncludeManagementTools) | Out-Null
		if (Get-Itemproperty "HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\PermittedManagers" | Select-Object -ExpandProperty 1 -ErrorAction Stop) {
			Remove-Itemproperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\PermittedManagers -Name 1
		}
		Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\RFC1156Agent -Name sysContact -Value "$SNMPsysContact"
		Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\RFC1156Agent -Name sysLocation -Value "$SNMPsysLocation"
		Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\RFC1156Agent -Name sysServices -Value 79 -Type DWord
		Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\ValidCommunities -Name public -Value 4 -Type DWord
	}
	# Set the Start Button to display All Apps rather than the silly start menu
	Set-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartPage -Name MakeAllAppsDefault -Value 1 -Type DWord
	# Install the Telnet Client and TFTP Client as we might need them at a later date
	(Add-WindowsFeature -Name Telnet-Client) | Out-Null
	(Add-WindowsFeature -Name TFTP-Client) | Out-Null
	# Disable IE Enhanced Security Configuration for Administrators of this server only
	Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}" -Name IsInstalled -Value 0 -Type DWord
	Stop-Process -Name Explorer
}



####################################################################################################################################################################################
Function InstallIISforSolidCP()			# Function to install SolidCP IIS (Basic Requirements)
{
	Write-Host "`tInstalling the features required for SolidCP to run on IIS Server" -ForegroundColor Cyan
	# Install the features required by SolidCP Server to run on the machine, this is the minimum requirements for SolidCP to be installed on the server.
	(Add-WindowsFeature -Name Web-Server, Web-WebServer, Web-Common-Http, Web-Default-Doc, Web-Dir-Browsing, Web-Http-Errors, Web-Static-Content, Web-Http-Redirect, Web-Health, Web-Http-Logging, Web-Log-Libraries, Web-Http-Tracing, Web-Performance, Web-Stat-Compression, Web-Security, Web-Filtering, Web-Client-Auth, Web-Windows-Auth, Web-App-Dev, Web-Net-Ext, Web-Net-Ext45, Web-Asp-Net, Web-Asp-Net45, Web-ISAPI-Ext, Web-ISAPI-Filter, Web-Mgmt-Tools, Web-Mgmt-Console, Web-Scripting-Tools) | Out-Null
}


####################################################################################################################################################################################
Function InstallIISforHosting()			# Function to install additional IIS features for Web Server (Customer Hosting Requirements)
{
	Write-Host "`tInstalling the features required for Microsoft IIS Server (Web Hosting)" -ForegroundColor Cyan
	# Install the additional features required for a customer web server or shared hosting server that will be public facing
	(Add-WindowsFeature -Name Web-ODBC-Logging, Web-Request-Monitor, Web-Basic-Auth, Web-IP-Security, Web-ASP, Web-CGI, Web-Mgmt-Compat, Web-Metabase, Web-Lgcy-Mgmt-Console, Web-Lgcy-Scripting, Web-WMI, SMTP-Server) | Out-Null
	# Configure all logging options to be enabled for websites in IIS
	Set-WebConfigurationProperty -Filter System.Applicationhost/Sites/SiteDefaults/logfile -Name LogExtFileFlags -Value "Date,Time,ClientIP,UserName,SiteName,ComputerName,ServerIP,Method,UriStem,UriQuery,HttpStatus,Win32Status,BytesSent,BytesRecv,TimeTaken,ServerPort,UserAgent,Cookie,Referer,ProtocolVersion,Host,HttpSubStatus"
}


####################################################################################################################################################################################
Function InstallFTPforHosting()			# Function to install additional IIS features for FTP Server (Customer Hosting Requirements)
{
	Write-Host "`tInstalling the features required for Microsoft FTP Server" -ForegroundColor Cyan
	# Install the additional features required for a customer FTP server or shared hosting server that will be public facing
	(Add-WindowsFeature -Name Web-Ftp-Server, Web-Ftp-Service) | Out-Null
	Write-Host "`tConfiguring the FTP Server on this machine" -ForegroundColor Cyan
	# Check if the FTP Server is installed on this machine, if it check to make sure the Default FTP Site is not setup, then set it up corectly for SolidCP
	If ( ((Get-WindowsFeature *Web-Ftp-Service*).Installed[0]) -And !(Test-Path "IIS:\Sites\Default FTP Site" -pathType container) ) {
		# Create a local group called "SCPFtpUsers" on the local web server unless it already exists
		CreateLocalUserOrGroup "SCPFtpUsers" "SolidCP FTP Users Group  ********* DO NOT DELETE *********" "Group"
		# Create the "ftproot" folder in "C:\inetpub" if it doesnt exist
		if(!(Test-Path "$env:SystemDrive\inetpub\ftproot")) {New-Item "$env:SystemDrive\inetpub\ftproot" -itemType directory}
		# Grant permissions for the "C:\inetpub\ftproot" folder to the SCPFtpUsers Group (Read ONLY Access)
		SetAccessToFolder "C:\inetpub\ftproot" "SCPFtpUsers" "Read" "Allow"
		# Create the FTP Site for SolidCP only if it does not alreayd exist
		if (!(Test-Path "IIS:\Sites\Default FTP Site" -pathType container)) { # Setup the SolifCP FTP Site only if it doesn't already exist
			Import-Module WebAdministration
			$ip=get-WmiObject Win32_NetworkAdapterConfiguration|Where {$_.Ipaddress.length -gt 1}	# Get IPV4 Address for FTP Binding information
			$bindings = '@{protocol="ftp";bindingInformation="'+ $ip.ipaddress[0] +':21:"}'			# Setup the Bindings for the FTP Site with the IP Address gathered above
			New-Item "IIS:\Sites\Default FTP Site" -bindings $bindings -physicalPath "%SystemDrive%\inetpub\ftproot" -Verbose:$false | Out-Null # Create site with directory
			# Ensure the settings are correct for the FTP Server to enure security
			Set-ItemProperty "IIS:\Sites\Default FTP Site" -Name ftpServer.security.ssl.controlChannelPolicy -Value 0 # Allow SSL connections
			Set-ItemProperty "IIS:\Sites\Default FTP Site" -Name ftpServer.security.ssl.dataChannelPolicy -Value 0    # Allow SSL connections
			Set-ItemProperty "IIS:\Sites\Default FTP Site" -Name ftpServer.security.authentication.basicAuthentication.enabled -Value $true # Enable Basic Authentication
			Set-ItemProperty "IIS:\Sites\Default FTP Site" -Name ftpServer.security.authentication.anonymousAuthentication.enabled -Value $false # Disable Anonymous Authentication
			Set-ItemProperty "IIS:\Sites\Default FTP Site" -Name ftpserver.userisolation.mode -Value 0  # Set USer Isolation
			Set-ItemProperty "IIS:\Sites\Default FTP Site" -Name ftpserver.logFile.directory -Value "%SystemDrive%\inetpub\logs\LogFiles"  # Set Log File Directory
			# Configure all logging options to be enabled for FTP Sites in IIS
			Set-WebConfigurationProperty -Filter "system.applicationHost/sites/siteDefaults/ftpServer/logFile" -Name LogExtFileFlags -Value "Date,Time,ClientIP,UserName,SiteName,ComputerName,ServerIP,Method,UriStem,FtpStatus,Win32Status,BytesSent,BytesRecv,TimeTaken,ServerPort,Host,FtpSubStatus,Session,FullPath,Info,ClientPort"
			# Give Authorization to SCPFtpUsers and grant "read" privileges in IIS (Default FTP Site)
			Add-WebConfiguration "/system.ftpServer/security/authorization" -value @{accessType="Allow";roles="SCPFtpUsers";permissions="Read";users=""} -PSPath IIS:\ -location "Default FTP Site"
			Restart-WebItem "IIS:\Sites\Default FTP Site"  # Restart the FTP site for all changes to take effect
		}
	}
}


####################################################################################################################################################################################
Function CreateLocalUserOrGroup($dName, $dDescription, $dType)			# Create a Local User or Group if it does not exist
{ # Usage - CreateLocalUserOrGroup "Local [User|Group] Name" "Description" "User|Group"
	if (!([ADSI]::Exists("WinNT://$env:computername/$dName"))) {
		invoke-command {$cn=[ADSI]"WinNT://$env:computername";$name=$cn.Create("$dType", "$dName");$name.SetInfo();$name.description=("$dDescription");$name.SetInfo()}
	}
}


####################################################################################################################################################################################
Function AddLocalUserToLocalGroup($dGroupName, $dUserName)				# Add a Local User to a Local Group if it is not already a member
{ # Usage - AddLocalUserToLocalGroup "Local Group Name" "Local User Name"
	if (!([ADSI]::Exists("WinNT://$env:computername/$dGroupName"))) {
		Write-Host "`t Local Group `"$env:computername/$dGroupName`" does not exist`!" -ForegroundColor Red
	}elseif (!([ADSI]::Exists("WinNT://$env:computername/$dUserName"))) {
		Write-Host "`t Local User `"$env:computername/$dUserName`" does not exist`!" -ForegroundColor Red
	}else{
		if (( @( ([ADSI]"WinNT://$env:computername/$dGroupName").psbase.Invoke("Members") )| ForEach-Object{$_.GetType().InvokeMember("Name", "GetProperty", $null, $_, $null);}) -notcontains $dUserName) {
			invoke-command {$group = [ADSI]"WinNT://$env:computername/$dGroupName,group";$group.Add("WinNT://$env:computername/$dUserName");$group.SetInfo()}
		}
	}
}


####################################################################################################################################################################################
Function CheckGroupMembers($dGroupName, $dUserName) 					# Check if a Local Users is a member of a Local Group (returns True or False)
{ # Usage - CheckGroupMembers "Local Group Name" "Local User Name"
	$MemberNames = @()
	$dMembers = @( ([ADSI]"WinNT://$env:computername/$dGroupName").psbase.Invoke("Members") )| ForEach-Object{$_.GetType().InvokeMember("Name", "GetProperty", $null, $_, $null);}
	($dMembers -contains "$dUserName")
}


####################################################################################################################################################################################
Function SetAccessToFolder ($dFolder, $dName, $dAccessRights, $dType)		# Set access for a Local User or Local Group to a folder if the user, group or folder exists 
{ # Usage - SetAccessToFolder "C:\HostingSpaces" "User|Group" "Read|ReadAndExecute|Change|Modify|ListFolderContents|FullControl" "Allow|Deny"
	if (!([ADSI]::Exists("WinNT://$env:computername/$dName"))) {
		Write-Host "`t The Local User or Group `"$dName`" does not exist`!" -ForegroundColor Red
	}elseif (!(Test-Path "$dFolder")) {
		Write-Host "`t The Folder does not exist`!" -ForegroundColor Red
	}else{
		$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("$dName", "$dAccessRights", [system.security.accesscontrol.InheritanceFlags]"ContainerInherit, ObjectInherit", [system.security.accesscontrol.PropagationFlags]"None", "$dType")
		$Acl        = (Get-Item "$dFolder").GetAccessControl('Access')
		$Acl.AddAccessRule($AccessRule)
		Set-ACL -Path "$dFolder" -AclObject $Acl
		invoke-command {$AccessRule} | Out-Null
	}
}


####################################################################################################################################################################################
Function SetAccessToFolderNoChk ($dFolder, $dName, $dAccessRights, $dType)	# Set access for a User or Group to a folder if the folder exists (doesn't check the user or group)
{ # Usage - SetAccessToFolderNoChk "C:\HostingSpaces" "User|Group" "Read|ReadAndExecute|Change|Modify|ListFolderContents|FullControl" "Allow|Deny"
	if (!(Test-Path "$dFolder")) {
		Write-Host "`t The Folder does not exist`!" -ForegroundColor Red
	}else{
		$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("$dName", "$dAccessRights", [system.security.accesscontrol.InheritanceFlags]"ContainerInherit, ObjectInherit", [system.security.accesscontrol.PropagationFlags]"None", "$dType")
		$Acl        = (Get-Item "$dFolder").GetAccessControl('Access')
		$Acl.AddAccessRule($AccessRule)
		Set-ACL -Path "$dFolder" -AclObject $Acl
		invoke-command {$AccessRule} | Out-Null
	}
}


####################################################################################################################################################################################
Function RemoveAccessToFolder ($dFolder, $dName, $dAccessRights, $dType)		# Remove access for a User or Group to a folder if the user, group or folder exists
{ # Usage - RemoveAccessToFolder "C:\HostingSpaces" "User|Group" "Read|ReadAndExecute|Change|Modify|ListFolderContents|FullControl" "Allow|Deny"
	if (!([ADSI]::Exists("WinNT://$env:computername/$dName"))) {
		Write-Host "`t The Local User or Group `"$dName`" does not exist`!" -ForegroundColor Red
	}elseif (!(Test-Path "$dFolder")) {
		Write-Host "`t The Folder does not exist`!" -ForegroundColor Red
	}else{
		$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($dName,$dAccessRights, 'ContainerInherit,ObjectInherit', 'None', "$dType")
		$Acl        = (Get-Item "$dFolder").GetAccessControl('Access')
		$Acl.RemoveAccessRuleAll($AccessRule)
		Set-Acl -Path "$dFolder" -AclObject $Acl
	}
}


####################################################################################################################################################################################
Function RemoveAccessToFolderNoChk ($dFolder, $dName, $dAccessRights, $dType)	# Remove access for a User or Group to a folder if the user, group or folder exists
{ # Usage - RemoveAccessToFolderNoChk "C:\HostingSpaces" "User|Group" "Read|ReadAndExecute|Change|Modify|ListFolderContents|FullControl" "Allow|Deny"
	if (!(Test-Path "$dFolder")) {
		Write-Host "`t The Folder does not exist`!" -ForegroundColor Red
	}else{
		$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($dName,$dAccessRights, 'ContainerInherit,ObjectInherit', 'None', "$dType")
		$Acl        = (Get-Item "$dFolder").GetAccessControl('Access')
		$Acl.RemoveAccessRuleAll($AccessRule)
		Set-Acl -Path "$dFolder" -AclObject $Acl
	}
}


####################################################################################################################################################################################
Function SetAccessToFiles ($dFileLocation, $dName, $dAccessRights, $dType)	# Set access for a User or Group to a files within a folder if the user or group exists 
{ # Usage - SetAccessToFiles "C:\HostingSpaces\*.txt" "User|Group" "Read|ReadAndExecute|Change|Modify|ListFolderContents|FullControl" "Allow|Deny"
	if (!([ADSI]::Exists("WinNT://$env:computername/$dName"))) {
		Write-Host "`t The Local User or Group `"$dName`" does not exist`!" -ForegroundColor Red
	}else{
		Get-ChildItem $dFileLocation |  ForEach {
			$AccessRule = New-Object  System.Security.AccessControl.FileSystemAccessRule("$dName","$dAccessRights","$dType")
			$Acl        = Get-Acl "$_"
			$Acl.SetAccessRule($AccessRule)
			Set-Acl -Path "$_" -AclObject $Acl
		}
	}
}


####################################################################################################################################################################################
Function RemoveAccessToFiles ($dFileLocation, $dName, $dAccessRights, $dType)	# Grant access for a User or Group to a folder if the user or group exists 
{ # Usage - RemoveAccessToFiles "C:\HostingSpaces\*.txt" "User|Group" "Read|ReadAndExecute|Change|Modify|ListFolderContents|FullControl" "Allow|Deny"
	if (!([ADSI]::Exists("WinNT://$env:computername/$dName"))) {
		Write-Host "`t The Local User or Group `"$dName`" does not exist`!" -ForegroundColor Red
	}else{
		Get-ChildItem $dFileLocation |  ForEach {
			$AccessRule = New-Object  System.Security.AccessControl.FileSystemAccessRule($dName,"$dAccessRights","$dType")
			$Acl        = Get-Acl "$_"
			$Acl.RemoveAccessRuleAll($AccessRule)
			Set-Acl -Path "$_" -AclObject $Acl
		}
	}
}


####################################################################################################################################################################################
Function DisableFolderInheritance ($dFolder)	# Disable inheritance on the folder specified
{ # Usage - DisableFolderInheritance "C:\HostingSpaces"
if (!(Test-Path "$dFolder")) {
		Write-Host "`t The `"$dFolder`" folder does not exist`!" -ForegroundColor Red
	}else{
		$acl = Get-ACL -Path $dFolder
		$acl.SetAccessRuleProtection($True, $True)
		Set-Acl -Path $dFolder -AclObject $acl | Out-Null
	}
}


####################################################################################################################################################################################
Function EnableFolderInheritance ($dFolder)		# Enable inheritance on the folder specified
{ # Usage - EnableFolderInheritance "C:\HostingSpaces"
if (!(Test-Path "$dFolder")) {
		Write-Host "`t The `"$dFolder`" folder does not exist`!" -ForegroundColor Red
	}else{
		$acl = Get-ACL -Path $dFolder
		$acl.SetAccessRuleProtection($false, $false)
		Set-Acl -Path $dFolder -AclObject $acl | Out-Null
	}
}


####################################################################################################################################################################################
Function InstallDisablePasswdComplex()	# Disable Password Complexity Policy – Local Security Policy
{
	Write-Host "`tDisabling Password Complexity Policy – Local Security Policy" -ForegroundColor Cyan
	(secedit /export /cfg c:\secpol.cfg) | Out-Null;
	((gc C:\secpol.cfg).replace("PasswordComplexity = 1", "PasswordComplexity = 0") | Out-File C:\secpol.cfg) | Out-Null;
	(secedit /configure /db c:\windows\security\local.sdb /cfg c:\secpol.cfg /areas SECURITYPOLICY) | Out-Null;
	rm -force c:\secpol.cfg -confirm:$false
}


####################################################################################################################################################################################
Function InstallIISforESandPortal()		# Function to install additional IIS features required by the SolidCP Enterprise Server and Portal
{
	Write-Host "`tInstalling the features required for the SolidCP Enterprise Server and Portal" -ForegroundColor Cyan
	# Install the additional features required for SolidCP to be able to send emails from the Enterpeise Server
	(Add-WindowsFeature -Name Web-Lgcy-Mgmt-Console, SMTP-Server) | Out-Null
	# Change the "Default Website" port from 80 to 8080 so that we can install SolidCP on Port 80
	if ( (Get-WebBinding -Name 'Default Web Site').bindingInformation -eq "*:80:" ) {
		Set-WebBinding -Name 'Default Web Site' -BindingInformation "*:80:" -PropertyName Port -Value 8080
	}
}


####################################################################################################################################################################################
Function InstallDNSServer()				# Function to install features for Microsoft DNS Server
{
	Write-Host "`tInstalling the features required for Microsoft DNS Server" -ForegroundColor Cyan
	# Install the additional features required for the Microsoft DNS Server
	(Add-WindowsFeature -Name DNS, RSAT-DNS-Server) | Out-Null
	# Remove the DNS Root Hints for security and to stop the DNS Servers being used in Amplification Attacks
	Get-DnsServerRootHint | Remove-DnsServerRootHint -force
}


####################################################################################################################################################################################
Function InstallRDShostServer()			# Function to install features for the RDS Host Server
{
	Write-Host "`tInstalling the features required for the Remote Desktop Host Server" -ForegroundColor Cyan
	# Install the additional features required for the Microsoft RDS Host Server (RemoteApps or Remote Desktop)
	(Add-WindowsFeature -Name RSAT-AD-PowerShell) | Out-Null
}


####################################################################################################################################################################################
Function InstallActiveDirectory()		# Function to install features for Active Directory
{
	Write-Host "`tInstalling the features required for Active Directory" -ForegroundColor Cyan
	# Install the features required for this server to run Active Directory (Domain Controllers)
	(Add-WindowsFeature -Name AD-Domain-Services, RSAT-AD-Tools, RSAT-AD-PowerShell, RSAT-ADDS, RSAT-AD-AdminCenter, RSAT-ADDS-Tools, WDS-AdminPack -IncludeManagementTools) | Out-Null
}


####################################################################################################################################################################################
Function InstallActivePerl()			# Function to install Perl - ActiverPerl v5.22.1
{
	# Check if Perl is installed, if not then install the correct version for the server
	if ( !(Test-Path "C:\Perl64") -or (Test-Path "C:\Perl\") ) {
		# Perl is not installed on this server so go ahead and install it
		Write-Host "`tDetermining your Operating System Type and installing the correct version of Perl" -ForegroundColor Cyan
		# Create the Perl ActivePerl Directory in our Installation Files folder ready for downloading
		(md -Path 'C:\_Install Files\Perl - ActivePerl v5.22.1' -Force) | Out-Null ; cd 'C:\_Install Files\Perl - ActivePerl v5.22.1\'
		# Download the files required for Perl, then install them. This downloads the correct version for the OS and then installs it.
		if ([Environment]::Is64BitProcess) {
			Write-Host "`t Downloading the 64bit version of Perl" -ForegroundColor Green
			(New-Object System.Net.WebClient).DownloadFile("http://downloads.activestate.com/ActivePerl/releases/5.22.1.2201/ActivePerl-5.22.1.2201-MSWin32-x64-299574.msi", "C:\_Install Files\Perl - ActivePerl v5.22.1\ActivePerl-5.22.1.2201-MSWin32-x64-299574.msi") | Out-Null
			Write-Host "`t Installing the 64bit version of Perl" -ForegroundColor Green
			(Start-Process -FilePath 'C:\_Install Files\Perl - ActivePerl v5.22.1\ActivePerl-5.22.1.2201-MSWin32-x64-299574.msi' -Argumentlist "/passive" -Wait -Passthru).ExitCode | Out-Null
			# Add the Perl ISAPI and CGI Restrictions for Perl (64 bit)
			Write-Host "`t Adding the Perl ISAPI and CGI Restrictions in IIS" -ForegroundColor Green
			Add-WebConfiguration -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.webServer/security/isapiCgiRestriction' -value @{description='Perl FastCGI' ; path= "C:\Perl64\bin\perl.exe `"%s`" %s" ; allowed='True'}
			# Add the Perl Handler Mappings for Perl (64 bit)
			Write-Host "`t Adding the Perl Handler Mappings in IIS" -ForegroundColor Green
			New-WebHandler -Name "Perl_Script_Map_PL" -Path "*.pl" -Verb '*' -Modules CgiModule -ScriptProcessor 'C:\Perl64\bin\perl.exe "%s" %s' -ResourceType File
			New-WebHandler -Name "Perl_Script_Map_CGI" -Path "*.cgi" -Verb '*' -Modules CgiModule -ScriptProcessor 'C:\Perl64\bin\perl.exe "%s" %s' -ResourceType File
		}else{
			Write-Host "`t Downloading the 32bit version of Perl" -ForegroundColor Green
			(New-Object System.Net.WebClient).DownloadFile("http://downloads.activestate.com/ActivePerl/releases/5.22.1.2201/ActivePerl-5.22.1.2201-MSWin32-x86-64int-299574.msi", "C:\_Install Files\Perl - ActivePerl v5.22.1\ActivePerl-5.22.1.2201-MSWin32-x86-64int-299574.msi") | Out-Null
			Write-Host "`t Installing the 32bit version of Perl" -ForegroundColor Green
			(Start-Process -FilePath 'C:\_Install Files\Perl - ActivePerl v5.22.1\ActivePerl-5.22.1.2201-MSWin32-x86-64int-299574.msi' -Argumentlist "/passive" -Wait -Passthru).ExitCode | Out-Null
			# Add the Perl ISAPI and CGI Restrictions for Perl (32 bit)
			Write-Host "`t Adding the Perl ISAPI and CGI Restrictions in IIS" -ForegroundColor Green
			Add-WebConfiguration -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.webServer/security/isapiCgiRestriction' -value @{description='Perl FastCGI' ; path= "C:\Perl\bin\perl.exe `"%s`" %s" ; allowed='True'}
			# Add the Perl Handler Mappings for Perl (32 bit)
			Write-Host "`t Adding the Perl Handler Mappings in IIS" -ForegroundColor Green
			New-WebHandler -Name "Perl_Script_Map_PL" -Path "*.pl" -Verb '*' -Modules CgiModule -ScriptProcessor 'C:\Perl\bin\perl.exe "%s" %s' -ResourceType File
			New-WebHandler -Name "Perl_Script_Map_CGI" -Path "*.cgi" -Verb '*' -Modules CgiModule -ScriptProcessor 'C:\Perl\bin\perl.exe "%s" %s' -ResourceType File
		}
	cd '\'
	}
}


####################################################################################################################################################################################
Function InstallWebPI()					# Function to install Microsoft Web Platform Installer
{
	# Check if WebPI is installed, if not then install the correct version for the server
	if ( !(Test-Path "C:\Program Files\Microsoft\Web Platform Installer\") ) {
		# WebPI is not installed on this server so go ahead and install it
		Write-Host "`tDetermining your Operating System Type and installing the correct version of WebPI" -ForegroundColor Cyan
		# Create the WebPI Directory in our Installation Files folder ready for downloading
		(md -Path 'C:\_Install Files\WebPI' -Force) | Out-Null ; cd 'C:\_Install Files\WebPI\'
		if ([Environment]::Is64BitProcess){ # Download and install the 64 bit version if the operating system is 64 bit.
			Write-Host "`t Downloading the 64bit version of Web Platform Installer" -ForegroundColor Green
			(New-Object System.Net.WebClient).DownloadFile("http://download.microsoft.com/download/C/F/F/CFF3A0B8-99D4-41A2-AE1A-496C08BEB904/WebPlatformInstaller_amd64_en-US.msi", "C:\_Install Files\WebPI\WebPlatformInstaller_amd64_en-US.msi") | Out-Null
			Write-Host "`t installing the 64bit version of Web Platform Installer" -ForegroundColor Green
			(Start-Process -FilePath 'C:\_Install Files\WebPI\WebPlatformInstaller_amd64_en-US.msi' -Argumentlist "/passive" -Wait -Passthru).ExitCode | Out-Null
		}else{								# Download and install the 32 bit version if the operating system is 32 bit.
			Write-Host "`t Downloading the 32bit version of Web Platform Installer" -ForegroundColor Green
			(New-Object System.Net.WebClient).DownloadFile("http://download.microsoft.com/download/C/F/F/CFF3A0B8-99D4-41A2-AE1A-496C08BEB904/WebPlatformInstaller_x86_en-US.msi", "C:\_Install Files\WebPI\WebPlatformInstaller_x86_en-US.msi") | Out-Null
			Write-Host "`t installing the 32bit version of Web Platform Installer" -ForegroundColor Green
			(Start-Process -FilePath 'C:\_Install Files\WebPI\WebPlatformInstaller_x86_en-US.msi' -Argumentlist "/passive" -Wait -Passthru).ExitCode | Out-Null
		}
		cd 'C:\'
		start-Sleep -Seconds 10
	}
}


####################################################################################################################################################################################
Function InstallWebPI_PHP()				# Function to install PHP from the WebPI Command Line
{
	Write-Host "`tWebPI is installing PHP (v5.3, v5.4, v5.5, v5.6) and PHP Manager for IIS" -ForegroundColor Cyan
	cd "C:\Program Files\Microsoft\Web Platform Installer\"
	if ( !(Test-Path "C:\Program Files (x86)\PHP\v5.3\") ) { Write-Host "`t Installing PHP v5.3" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:PHP53 /AcceptEULA}) | Out-Null }
	if ( !(Test-Path "C:\Program Files (x86)\PHP\v5.4\") ) { Write-Host "`t Installing PHP v5.4" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:PHP54 /AcceptEULA}) | Out-Null }
	if ( !(Test-Path "C:\Program Files (x86)\PHP\v5.5\") ) { Write-Host "`t Installing PHP v5.5" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:PHP55 /AcceptEULA}) | Out-Null }
	if ( !(Test-Path "C:\Program Files (x86)\PHP\v5.6\") ) { Write-Host "`t Installing PHP v5.6" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:PHP56 /AcceptEULA}) | Out-Null }
	if ( !(Test-Path "C:\Program Files\PHP Manager 1.2 for IIS 7\") ) { Write-Host "`t Installing PHP Manager for IIS" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:PHPManager /AcceptEULA}) | Out-Null }
	cd '\'
}


####################################################################################################################################################################################
Function InstallWebPI_Python()			# Function to install Python v3.4 from the WebPI Command Line
{
	Write-Host "`tWebPI is installing Python v3.4 for IIS" -ForegroundColor Cyan
	cd "C:\Program Files\Microsoft\Web Platform Installer\"
	if ( !(Test-Path "C:\Python34\") ) { Write-Host "`t Installing Python v3.4" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:Python34 /AcceptEULA}) | Out-Null }
	cd '\'
}


####################################################################################################################################################################################
Function InstallWebPI_SQLdriverPHP()	# Function to install the SQL Driver for PHP from the WebPI Command Line
{
	Write-Host "`tWebPI is installing the SQL Driver for PHP" -ForegroundColor Cyan
	cd "C:\Program Files\Microsoft\Web Platform Installer\"
	if ( !(Test-Path "C:\Program Files (x86)\PHP\v5.3\ext\php_sqlsrv.dll") ) { Write-Host "`t Installing the SQL Driver for PHP v5.3" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:SQLDriverPHP53IIS /AcceptEULA}) | Out-Null }
	if ( !(Test-Path "C:\Program Files (x86)\PHP\v5.4\ext\php_sqlsrv.dll") ) { Write-Host "`t Installing the SQL Driver for PHP v5.4" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:SQLDriverPHP54IIS /AcceptEULA}) | Out-Null }
	if ( !(Test-Path "C:\Program Files (x86)\PHP\v5.5\ext\php_sqlsrv.dll") ) { Write-Host "`t Installing the SQL Driver for PHP v5.5" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:SQLDriverPHP55IIS /AcceptEULA}) | Out-Null }
	if ( !(Test-Path "C:\Program Files (x86)\PHP\v5.6\ext\php_sqlsrv.dll") ) { Write-Host "`t Installing the SQL Driver for PHP v5.6" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:SQLDriverPHP56IIS /AcceptEULA}) | Out-Null }
	cd '\'
}


####################################################################################################################################################################################
Function InstallWebPI_URLreWrite()		# Function to install the URL Rewrite module from the WebPI Command Line
{
	Write-Host "`tWebPI is installing the URL ReWrite module for IIS" -ForegroundColor Cyan
	cd "C:\Program Files\Microsoft\Web Platform Installer\"
	if ( !(Test-Path "HKLM:\SOFTWARE\Microsoft\IIS Extensions\URL Rewrite\") ) { Write-Host "`t Installing the URL ReWrite module for IIS" ; (invoke-command {.\WebPICMD.exe /Install /Products:UrlRewrite2 /AcceptEULA}) | Out-Null }
	cd '\'
}


####################################################################################################################################################################################
Function InstallWebPI_WebDeploy()		# Function to install the Web Deploy module from the WebPI Command Line
{
	Write-Host "`tWebPI is installing the Web Deploy module for IIS" -ForegroundColor Cyan
	cd "C:\Program Files\Microsoft\Web Platform Installer\"
	if ( !(Test-Path "C:\Program Files\IIS\Microsoft Web Deploy V3\") ) { Write-Host "`t Installing the Web Deploy module for IIS" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:WDeployNoSMO /AcceptEULA}) | Out-Null }
	cd '\'
}


####################################################################################################################################################################################
Function InstallWebPI_MySQL($dMySQLpassword)			# Function to install the MySQL Database Server from the WebPI Command Line
{
	Write-Host "`tWebPI is installing the MySQL Database Server" -ForegroundColor Cyan
	cd "C:\Program Files\Microsoft\Web Platform Installer\"
	if ( !(Test-Path "C:\Program Files\MySQL\MySQL Server 5.1\") ) {		# Check if the MySQL Database Server is already installed
		# Check if a password has been passed into the function, if not prompt for one to be entered
		if (!$dMySQLpassword) { $responseMySQL = Read-host "`nEnter the ROOT password you want to use for your MySQL Server" -AsSecureString ; $dMySQLpassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($responseMySQL)) }
		# Install the MySQL Database Server
		Write-Host "`t Installing the MySQL Database Server" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:MySQL /AcceptEULA /MySQLPassword:$dMySQLpassword}) | Out-Null
	}
	if ( !(Test-Path "C:\Program Files (x86)\MySQL\MySQL Connector Net 6.9.7\") ) {					# Check if the MySQL Connector Net v6.9.7 is already installed
		# Install the MySQL Connector Net v6.9.7
		Write-Host "`t Installing the MySQL Connector Net v6.9.7" -ForegroundColor Green ; (invoke-command {.\WebPICMD.exe /Install /Products:MySQLConnector /AcceptEULA}) | Out-Null
	}
	cd '\'
}


####################################################################################################################################################################################
Function InstallFirewall_MySQL()		# Function to install the Firewall Rule for the MySQL Database Server
{
	Write-Host "`tOpening port 3306 for the MySQL Database Server on the Firewall" -ForegroundColor Cyan
	# Add the firewall rule to open Port 3306 for inbound management of the MySQL Server 5.1 only if it doesn't exist
	if ( !(Get-NetFirewallRule | where DisplayName -EQ "MySQL Server - Port 3306") ) {
		(New-NetFirewallRule -DisplayName "MySQL Server - Port 3306" -Direction Inbound –LocalPort 3306 -Protocol TCP -Action Allow) | Out-Null
		Write-Host "`t Firewall rule added successfully" -ForegroundColor Green
	}
}


####################################################################################################################################################################################
Function InstallSQLsvr2014withTools($dMsSQLpassword)	# Function to install SQL Server 2014 Express (with tools)
{
	if ( !(Test-Path "C:\Program Files\Microsoft SQL Server\MSSQL12.SQLEXPRESS\MSSQL\DATA\") ) { 
		# Check if a password has been passed into the function, if not prompt for one to be entered
		if (!$dMsSQLpassword) {
			$responseMsSQL = Read-host "`nEnter the SA password you want to use for your Microsoft SQL Server" -AsSecureString
			$dMsSQLpassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($responseMsSQL))
		}

		Write-Host "`tDownloading SQL Server 2014 Express (with tools)" -ForegroundColor Cyan
		# Create the SQL Server 2014 Express with Tools Directory in our Installation Files folder ready for downloading
		(md -Path 'C:\_Install Files\SQL Server 2014 Express with Tools' -Force) | Out-Null ; cd 'C:\_Install Files\SQL Server 2014 Express with Tools\'
		# Download SQL Server 2014 Express with Tools x64 from Microsoft
		(New-Object System.Net.WebClient).DownloadFile("http://download.microsoft.com/download/E/A/E/EAE6F7FC-767A-4038-A954-49B8B05D04EB/ExpressAndTools%2064BIT/SQLEXPRWT_x64_ENU.exe", "C:\_Install Files\SQL Server 2014 Express with Tools\SQLEXPRWT_x64_ENU.exe")

		# Install the SQL Server 2014 Express with Tools x64 on the Server
		Write-Host "`t Extracting and Installing SQL Server 2014 Express (with tools)`n" -ForegroundColor Green
		Write-Host "`t    ****************************************" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    *     This will take quite a while     *" -ForegroundColor Green
		Write-Host "`t    *           to fully complete          *" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    *  Please be patient while we install  *" -ForegroundColor Green
		Write-Host "`t    *       SQL Server 2014 Express        *" -ForegroundColor Green
		Write-Host "`t    *        With Management Tools         *" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    ****************************************" -ForegroundColor Green
		((Start-Process -FilePath 'C:\_Install Files\SQL Server 2014 Express with Tools\SQLEXPRWT_x64_ENU.exe' -Argumentlist "/Q /IACCEPTSQLSERVERLICENSETERMS=1 /SQLSYSADMINACCOUNTS=Administrator /ACTION=Install /INSTANCEID=SQLEXPRESS /INSTANCENAME=SQLExpress /TCPENABLED=1 /UPDATEENABLED=True /FEATURES=SQLENGINE,REPLICATION,CONN,BC,SDK,SSMS,ADV_SSMS,SNAC_SDK,Tools /SECURITYMODE=SQL /SAPWD=$dMsSQLpassword /INDICATEPROGRESS=False /SQMREPORTING=False /AGTSVCSTARTUPTYPE=Automatic /SQLSVCSTARTUPTYPE=Automatic /SQLCOLLATION=`"SQL_Latin1_General_CP1_CI_AS`" /BROWSERSVCSTARTUPTYPE=Automatic" -Wait -Passthru).ExitCode) | Out-Null
	}
}


####################################################################################################################################################################################
Function InstallSQLsvr2014noTools($dMsSQLpassword2)	# Function to install SQL Server 2014 Express (with tools)
{
	if ( !(Test-Path "C:\Program Files\Microsoft SQL Server\MSSQL12.SQLEXPRESS\MSSQL\DATA\") ) { 
		# Check if a password has been passed into the function, if not prompt for one to be entered
		if (!$dMsSQLpassword2) {
			$responseMsSQL2 = Read-host "`nEnter the SA password you want to use for your Microsoft SQL Server" -AsSecureString
			$dMsSQLpassword2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($responseMsSQL2))
		}

		Write-Host "`tDownloading SQL Server 2014 Express" -ForegroundColor Cyan
		# Create the SQL Server 2014 Express with Tools Directory in our Installation Files folder ready for downloading
		(md -Path 'C:\_Install Files\SQL Server 2014 Express' -Force) | Out-Null ; cd 'C:\_Install Files\SQL Server 2014 Express\'
		# Download SQL Server 2014 Express x64 from Microsoft
		(New-Object System.Net.WebClient).DownloadFile("https://download.microsoft.com/download/E/A/E/EAE6F7FC-767A-4038-A954-49B8B05D04EB/Express%2064BIT/SQLEXPR_x64_ENU.exe", "C:\_Install Files\SQL Server 2014 Express\SQLEXPR_x64_ENU.exe")

		# Install the SQL Server 2014 Express x64 on the Server
		Write-Host "`t Extracting and Installing SQL Server 2014 Express`n" -ForegroundColor Green
		Write-Host "`t    ****************************************" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    *     This will take quite a while     *" -ForegroundColor Green
		Write-Host "`t    *           to fully complete          *" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    *  Please be patient while we install  *" -ForegroundColor Green
		Write-Host "`t    *       SQL Server 2014 Express        *" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    ****************************************" -ForegroundColor Green
		((Start-Process -FilePath 'C:\_Install Files\SQL Server 2014 Express\SQLEXPR_x64_ENU.exe' -Argumentlist "/Q /IACCEPTSQLSERVERLICENSETERMS=1 /SQLSYSADMINACCOUNTS=Administrator /ACTION=Install /INSTANCEID=SQLEXPRESS /INSTANCENAME=SQLExpress /TCPENABLED=1 /UPDATEENABLED=True /FEATURES=SQLENGINE,REPLICATION,CONN,BC,SDK,SNAC_SDK /SECURITYMODE=SQL /SAPWD=$dMsSQLpassword2 /INDICATEPROGRESS=False /SQMREPORTING=False /AGTSVCSTARTUPTYPE=Automatic /SQLSVCSTARTUPTYPE=Automatic /SQLCOLLATION=`"SQL_Latin1_General_CP1_CI_AS`" /BROWSERSVCSTARTUPTYPE=Automatic" -Wait -Passthru).ExitCode) | Out-Null
	}
}


####################################################################################################################################################################################
Function InstallSQLsvr2014mgmtTools()	# Function to install SQL Server 2014 Express (with tools)
{
	if ( !(Test-Path "C:\Program Files (x86)\Microsoft SQL Server\120\Tools\Binn\ManagementStudio\Ssms.exe") ) { 
		Write-Host "`tDownloading SQL Server 2014 Express Management Tools" -ForegroundColor Cyan
		# Create the SQL Server 2014 Express with Tools Directory in our Installation Files folder ready for downloading
		(md -Path 'C:\_Install Files\SQL Server 2014 Express Management Tools' -Force) | Out-Null ; cd 'C:\_Install Files\SQL Server 2014 Express Management Tools\'
		# Download SQL Server 2014 Express Management Tools x64 from Microsoft
		(New-Object System.Net.WebClient).DownloadFile("https://download.microsoft.com/download/E/A/E/EAE6F7FC-767A-4038-A954-49B8B05D04EB/MgmtStudio%2064BIT/SQLManagementStudio_x64_ENU.exe", "C:\_Install Files\SQL Server 2014 Express Management Tools\SQLManagementStudio_x64_ENU.exe")

		# Install the SQL Server 2014 Express with Tools x64 on the Server
		Write-Host "`t Extracting and Installing SQL Server 2014 Express Management Tools`n" -ForegroundColor Green
		Write-Host "`t    ****************************************" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    *     This will take quite a while     *" -ForegroundColor Green
		Write-Host "`t    *           to fully complete          *" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    *  Please be patient while we install  *" -ForegroundColor Green
		Write-Host "`t    *       SQL Server 2014 Express        *" -ForegroundColor Green
		Write-Host "`t    *        Management Tools ONLY         *" -ForegroundColor Green
		Write-Host "`t    *                                      *" -ForegroundColor Green
		Write-Host "`t    ****************************************" -ForegroundColor Green
		((Start-Process -FilePath 'C:\_Install Files\SQL Server 2014 Express Management Tools\SQLManagementStudio_x64_ENU.exe' -Argumentlist "/Q /IACCEPTSQLSERVERLICENSETERMS=1 /ACTION=Install /UPDATEENABLED=True /FEATURES=SSMS,ADV_SSMS,Tools /INDICATEPROGRESS=False" -Wait -Passthru).ExitCode) | Out-Null
	}
}


####################################################################################################################################################################################
Function InstallSQLsvr2012NativeClnt()	# Function to install SQL Server 2012 Native Client
{
	if ( !(Test-Path "C:\Program Files\Microsoft SQL Server\110\SDK\Lib\x64\sqlncli11.lib") ) { 
		# Stopping the SQL Server Service
		Write-Host "`tStopping the SQL Server ready for the SQL Server 2012 Native Client Installation" -ForegroundColor Cyan
		Stop-Service 'MSSQL$SQLExpress' -Force
		Write-Host "`t Downloading the SQL Server 2012 Native Client" -ForegroundColor Green
		# Create the SQL Server 2012 Native Client Directory in our Installation Files folder ready for downloading
		(md -Path 'C:\_Install Files\SQL Server 2012 Native Client' -Force) | Out-Null ; cd 'C:\_Install Files\SQL Server 2012 Native Client\'
		# Download the SQL Server Native Client from Microsoft
		(New-Object System.Net.WebClient).DownloadFile("http://download.microsoft.com/download/4/B/1/4B1E9B0E-A4F3-4715-B417-31C82302A70A/ENU/x64/sqlncli.msi", "C:\_Install Files\SQL Server 2012 Native Client\sqlncli.msi")
		# Install the SQL Server Native Client on the Server
		Write-Host "`t Installing the SQL Server 2012 Native Client" -ForegroundColor Green
		((Start-Process -FilePath "C:\_Install Files\SQL Server 2012 Native Client\sqlncli.msi" -ArgumentList "/qb IACCEPTSQLNCLILICENSETERMS=YES" -Wait -Passthru).ExitCode) | Out-Null
		# Start the SQL Server Service
		Write-Host "`t Starting the SQL Server again as we have just installed the SQL Server 2012 Native Client" -ForegroundColor Green
		Start-Service 'MSSQL$SQLExpress'
	}
}


####################################################################################################################################################################################
Function InstallMSSQL_TCPports()		# Function to the TCP Ports and Named Pipes for the Microsoft SQL Database Server
{
	$dEnableSQLports = @'
	# Setup the enviroment to enable the ports
	$wmi = New-Object ('Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer')
	$Tcp = $wmi.GetSmoObject("ManagedComputer[@Name='$env:COMPUTERNAME']/ ServerInstance[@Name='SQLExpress']/ServerProtocol[@Name='Tcp']")

	# Enable TCP on the SQL Server
	$Tcp.IsEnabled = $true
	$TCP.alter()

	# Enabled TCP, Disbale Dynamic Ports and Set TCP Port as 1433 for all IP Addresses
	foreach ($ipAddress in $Tcp.IPAddresses)
	{
		if ($ipAddress.IPAddressProperties["Active"].Value) {
			$ipAddress.IPAddressProperties["Enabled"].Value=$True
		}
		$ipAddress.IPAddressProperties["TcpDynamicPorts"].Value = ""
		$ipAddress.IPAddressProperties["TcpPort"].Value = "1433"
	}
	$Tcp.Alter()

	# Enable the named pipes protocol for the default instance.
	$NamedPipes = $wmi.GetSmoObject("ManagedComputer[@Name='$env:COMPUTERNAME']/ ServerInstance[@Name='SQLExpress']/ServerProtocol[@Name='Np']")
	$NamedPipes.IsEnabled = $true
	$NamedPipes.Alter()

	# Exit the SQL PowerShell Enviroment
	exit
'@

	Write-Host "`tEnabling TCP and Named Pipes for the Microsoft SQL Database Server" -ForegroundColor Cyan
	# Register the SQL PowerShell Modules
	start-Sleep -Seconds 25
	(set-alias installutil $env:windir\microsoft.net\framework\v2.0.50727\installutil) | Out-Null
	(installutil -i “C:\Program Files (x86)\Microsoft SQL Server\120\Tools\PowerShell\Modules\SQLPS\Microsoft.SqlServer.Management.PSProvider.dll”) | Out-Null
	(installutil -i “C:\Program Files (x86)\Microsoft SQL Server\120\Tools\PowerShell\Modules\SQLPS\Microsoft.SqlServer.Management.PSSnapins.dll”) | Out-Null
	# Open the SQL PowerShell Enviroment and run the above command
	cd 'C:\Program Files (x86)\Microsoft SQL Server\120\Tools\Binn'
	invoke-expression "cmd /c start sqlps -Command {$dEnableSQLports}"
	# Restart the SQL Server Service
	Write-Host "`t Restarting the SQL Database Server" -ForegroundColor Yellow
	(Restart-Service 'MSSQL$SQLExpress' -Force) | Out-Null;
	Write-Host "`t Restarted successfully" -ForegroundColor Green
	sleep 1
}


####################################################################################################################################################################################
Function InstallFirewall_MSSQL()		# Function to install the Firewall Rule for the Microsoft SQL Database Server
{
	Write-Host "`tOpening port 1433 for the Microsoft SQL Database Server on the Firewall" -ForegroundColor Cyan
	# Add the firewall rule to open Port 1433 for inbound management of the Microsoft SQL Server only if it doesn't exist
	if ( !(Get-NetFirewallRule | where DisplayName -EQ "Microsoft SQL Server - Port 1433") ) {
		(New-NetFirewallRule -DisplayName "Microsoft SQL Server - Port 1433" -Direction Inbound –LocalPort 1433 -Protocol TCP -Action Allow) | Out-Null
		Write-Host "`t Firewall rule added successfully" -ForegroundColor Green
	}
}


####################################################################################################################################################################################
Function InstallExchangeCAS()			# Function to install the features required for the Microsoft Exchange CAS Server Role
{
	Write-Host "`tInstalling the features required for Microsoft Exchange Server (CAS Role)" -ForegroundColor Cyan
	(Add-WindowsFeature -Name AS-HTTP-Activation, Web-Request-Monitor, Web-Basic-Auth, Web-Digest-Auth, Web-Dyn-Compression, Web-Lgcy-Mgmt-Console, Web-Mgmt-Service, Web-Metabase, Web-WMI, NET-Framework-45-Features, Desktop-Experience, RSAT-Clustering, RSAT-ADDS, RPC-over-HTTP-proxy, Windows-Identity-Foundation, WAS-Process-Model, Web-IP-Security, NLB, RSAT-NLB) | Out-Null
}


####################################################################################################################################################################################
Function InstallExchangeMBX()			# Function to install the features required for the Microsoft Exchange Mailbox Server Role
{
	Write-Host "`tInstalling the features required for Microsoft Exchange Server (Mailbox Role)" -ForegroundColor Cyan
	(Add-WindowsFeature -Name AS-HTTP-Activation, Web-Request-Monitor, Web-Basic-Auth, Web-Digest-Auth, Web-Dyn-Compression, Web-Lgcy-Mgmt-Console, Web-Mgmt-Service, Web-Metabase, Web-WMI, NET-Framework-45-Features, Desktop-Experience, RSAT-Clustering, RSAT-ADDS, RPC-over-HTTP-proxy, Windows-Identity-Foundation, WAS-Process-Model, RSAT-Clustering-CmdInterface) | Out-Null
}


####################################################################################################################################################################################
Function InstallExchangeFSW()			# Function to install the features required for the Microsoft Exchange File Share Witness Server Role
{
	Write-Host "`tInstalling the features required for Microsoft Exchange Server (File Share Witness Role)" -ForegroundColor Cyan
	(Add-WindowsFeature -Name FS-FileServer) | Out-Null
}


####################################################################################################################################################################################
Function InstallAwStats()				# Function for downloading and installing AwStats
{
	if ( ( !(Test-Path "C:\AWStats\wwwroot\") ) -and ( !(Test-Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats") ) ) { 
		Write-Host "`tInstalling the features required for AwStats" -ForegroundColor Cyan
		# Install the additional IIS Requirements for AwStats
		(Add-WindowsFeature -Name Web-CGI) | Out-Null
		# Configure all logging options to be enabled for websites in IIS
		Set-WebConfigurationProperty -Filter System.Applicationhost/Sites/SiteDefaults/logfile -Name LogExtFileFlags -Value "Date,Time,ClientIP,UserName,SiteName,ComputerName,ServerIP,Method,UriStem,UriQuery,HttpStatus,Win32Status,BytesSent,BytesRecv,TimeTaken,ServerPort,UserAgent,Cookie,Referer,ProtocolVersion,Host,HttpSubStatus"
		# Create the AwStats Directory in our Installation Files folder ready for downloading if it doesn't already exist
		if (!(Test-Path 'C:\_Install Files\AwStats')) { (md -Path 'C:\_Install Files\AwStats' -Force) | Out-Null }
		# Download the files required for AwStats
		Write-Host "`t Downloading the latest version of AwStats" -ForegroundColor Green
		(New-Object System.Net.WebClient).DownloadFile("https://github.com/eldy/awstats/archive/develop.zip", "C:\_Install Files\AwStats\awstats.zip")
		# Get the highest current SolidCP Version from the Installer XML File from the SolidCP Installation Website
		[string]$dSolidCPversion = ((([xml](New-Object System.Net.WebClient).DownloadString("http://installer.solidcp.com/Data/ProductReleasesFeed-1.0.xml")).components.component.releases.release).version | measure -Maximum).Maximum
		# Download the latest SolidCP AwStats Viewer based upon the highest version above
		Write-Host "`t Downloading the latest version of the AwStats Viewer from the SolidCP website" -ForegroundColor Green
		(New-Object System.Net.WebClient).DownloadFile("http://installer.solidcp.com/Files/stable/Tools/SolidCP-AWStatsViewer-$dSolidCPversion.zip", "C:\_Install Files\AwStats\SolidCP-AWStatsViewer-$dSolidCPversion.zip")
		# Unzip the downloaded files to the C:\AwStats directory
		Write-Host "`t Extracting and installing AwStats from the downloaded files" -ForegroundColor Green
		Add-Type -assembly "system.io.compression.filesystem"
		[io.compression.zipfile]::ExtractToDirectory("C:\_Install Files\AwStats\awstats.zip", "C:\AWStats")
		[io.compression.zipfile]::ExtractToDirectory("C:\_Install Files\AwStats\SolidCP-AWStatsViewer-$dSolidCPversion.zip", "C:\AWStats\awstats-develop\wwwroot")
		( (Get-ChildItem "C:\AWStats\" -include *.cvsignore -recurse | foreach ($_) {remove-item $_.fullname}) ) | Out-Null
		(Move-Item "C:\AWStats\awstats-develop\wwwroot\LICENSE.txt" "C:\AWStats") | Out-Null
		(Move-Item "C:\AWStats\awstats-develop\wwwroot\Readme.htm" "C:\AWStats") | Out-Null
		(Move-Item "C:\AWStats\awstats-develop\wwwroot\Web-v2.0.config" "C:\AWStats") | Out-Null
		(Move-Item "C:\AWStats\awstats-develop\docs\*"    "C:\AwStats\docs\") | Out-Null
		(Move-Item "C:\AWStats\awstats-develop\tools\*"   "C:\AwStats\tools\") | Out-Null
		(Move-Item "C:\AWStats\awstats-develop\wwwroot\*" "C:\AwStats\wwwroot\") | Out-Null
		(Remove-Item "C:\AWStats\awstats-develop" -Recurse) | Out-Null
		(md -Path  "C:\AWStats\wwwroot\bin\" -Force) | Out-Null
		(Move-Item "C:\AWStats\wwwroot\*.dll" "C:\AwStats\wwwroot\bin\") | Out-Null
		(Move-Item "C:\AWStats\wwwroot\SolidCP.AWStats.Viewer.dll.config" "C:\AwStats\wwwroot\bin\") | Out-Null
		(md -Path 'C:\AWStats\data') | Out-Null
		(md -Path 'C:\AWStats\logs') | Out-Null

		# Create the AwStats configuration File Template file
		(New-Item C:\AWStats\AwStats-Configuration-Template-File.txt -type file -force -value "LogFormat = `"%time2 %other %other %other %method %url %other %other %logname %host %other %ua %other %referer %other %code %other %other %bytesd %other %other`"`r`nLogSeparator = `" `"`r`nDNSLookup = 1`r`nDirCgi = `"/awstats/cgi-bin`"`r`nDirIcons = `"/awstats/icon`"`r`nAllowFullYearView=3`r`nAllowToUpdateStatsFromBrowser = 0`r`nUseFramesWhenCGI = 1`r`nShowFlagLinks = `"en fr de it nl es`"`r`nLogFile = `"[LOGS_FOLDER]\u_ex%YY-3%MM-3%DD-3.log`"`r`nDirData = `"C:\AWStats\data`"`r`nSiteDomain = `"[DOMAIN_NAME]`"`r`nHostAliases = [DOMAIN_ALIASES]`r`n") | Out-Null
		# Create the BAT File that will be used for AwStats to run the processing of website stats
		(New-Item C:\AWStats\UpdateStats.bat -type file -force) | Out-Null
		# Create the AwStats Scheduled Job as XML Format so we can import it
		(New-Item C:\AWStats\AwStats-Scheduled-Task-Import.xml -type file -force -value "<?xml version=`"1.0`" encoding=`"UTF-16`"?>`r`n<Task version=`"1.2`" xmlns=`"http://schemas.microsoft.com/windows/2004/02/mit/task`">`r`n  <RegistrationInfo>`r`n    <Date>2015-01-01T00:00:00.000000</Date>`r`n    <Author>BUILTIN\Administrator</Author>`r`n    <Description>Batch file that runs every 1 hour to poll each website that has Advanced Stats enabled on it.</Description>`r`n  </RegistrationInfo>`r`n  <Triggers>`r`n    <CalendarTrigger>`r`n      <Repetition>`r`n        <Interval>PT1H</Interval>`r`n        <Duration>P1D</Duration>`r`n        <StopAtDurationEnd>false</StopAtDurationEnd>`r`n      </Repetition>`r`n      <StartBoundary>2015-01-01T00:00:00</StartBoundary>`r`n      <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>`r`n      <Enabled>true</Enabled>`r`n      <ScheduleByDay>`r`n        <DaysInterval>1</DaysInterval>`r`n      </ScheduleByDay>`r`n    </CalendarTrigger>`r`n  </Triggers>`r`n  <Principals>`r`n    <Principal id=`"Author`">`r`n      <RunLevel>HighestAvailable</RunLevel>`r`n      <GroupId>BUILTIN\Administrators</GroupId>`r`n    </Principal>`r`n  </Principals>`r`n  <Settings>`r`n    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>`r`n    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>`r`n    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>`r`n    <AllowHardTerminate>true</AllowHardTerminate>`r`n    <StartWhenAvailable>true</StartWhenAvailable>`r`n    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>`r`n    <IdleSettings>`r`n      <StopOnIdleEnd>true</StopOnIdleEnd>`r`n      <RestartOnIdle>false</RestartOnIdle>`r`n    </IdleSettings>`r`n    <AllowStartOnDemand>true</AllowStartOnDemand>`r`n    <Enabled>true</Enabled>`r`n    <Hidden>false</Hidden>`r`n    <RunOnlyIfIdle>false</RunOnlyIfIdle>`r`n    <WakeToRun>false</WakeToRun>`r`n    <ExecutionTimeLimit>PT12H</ExecutionTimeLimit>`r`n    <Priority>7</Priority>`r`n    <RestartOnFailure>`r`n      <Interval>PT1M</Interval>`r`n      <Count>10</Count>`r`n    </RestartOnFailure>`r`n  </Settings>`r`n  <Actions Context=`"Author`">`r`n    <Exec>`r`n      <Command>C:\AWStats\UpdateStats.bat</Command>`r`n      <WorkingDirectory>C:\AWStats</WorkingDirectory>`r`n    </Exec>`r`n  </Actions>`r`n</Task>`r`n") | Out-Null
		# Create the task and import the settings from the XML file we created above
		(schtasks /create /XML C:\AWStats\AwStats-Scheduled-Task-Import.xml /tn "AwStats - Update Stats") | Out-Null
		# Change the bindings on the default website to Port 8080 so we can install AwStats on Port 80 unless it has already been done
		if ( (Get-WebBinding -Name 'Default Web Site').bindingInformation -eq "*:80:" ) {
			Set-WebBinding -Name 'Default Web Site' -BindingInformation "*:80:" -PropertyName Port -Value 8080
			# Another way to do the above is as per the line below
			#Set-WebConfigurationProperty "/system.applicationHost/sites/site[@name='Default Web Site']/bindings/binding[@protocol='http']" -name bindingInformation -value '*:8080:'
		}
		# Create the AppPool for AwStats
		Write-Host "`t Creating the AwStats Application Pool in IIS" -ForegroundColor Green
		(New-WebAppPool -Name "AwStats .NET v4" -Force) | Out-Null
		# Create the new website for AwStats
		Write-Host "`t Creating the AwStats website in IIS" -ForegroundColor Green
		(New-Website -Name "AwStats" -Port 80 -IPAddress "*" -PhysicalPath "C:\AWStats\wwwroot" -ApplicationPool "AwStats .NET v4" -Force) | Out-Null
		(Set-ItemProperty "IIS:\Sites\AwStats" -name logfile.directory "C:\AWStats\logs" -Force) | Out-Null
		# Grant Read & Execute permissions on wwwroot folder and Logs Folder
		invoke-command {$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS AppPool\AwStats .NET v4", "ReadAndExecute", [system.security.accesscontrol.InheritanceFlags]"ContainerInherit, ObjectInherit", [system.security.accesscontrol.PropagationFlags]"None", "Allow"); $acl = (Get-Item C:\AWStats\wwwroot).GetAccessControl('Access'); $acl.AddAccessRule($rule); Set-ACL -Path C:\AWStats\wwwroot -AclObject $acl}
		invoke-command {$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("BUILTIN\IIS_IUSRS", "ReadAndExecute", [system.security.accesscontrol.InheritanceFlags]"ContainerInherit, ObjectInherit", [system.security.accesscontrol.PropagationFlags]"None", "Allow"); $acl = (Get-Item C:\AWStats\wwwroot).GetAccessControl('Access'); $acl.AddAccessRule($rule); Set-ACL -Path C:\AWStats\wwwroot -AclObject $acl}
		invoke-command {$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("BUILTIN\Users", "ReadAndExecute", [system.security.accesscontrol.InheritanceFlags]"ContainerInherit, ObjectInherit", [system.security.accesscontrol.PropagationFlags]"None", "Allow"); $acl = (Get-Item C:\AWStats\wwwroot).GetAccessControl('Access'); $acl.AddAccessRule($rule); Set-ACL -Path C:\AWStats\wwwroot -AclObject $acl}
		invoke-command {$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("NT SERVICE\TrustedInstaller", "FullControl", [system.security.accesscontrol.InheritanceFlags]"ContainerInherit, ObjectInherit", [system.security.accesscontrol.PropagationFlags]"None", "Allow"); $acl = (Get-Item C:\AWStats\logs).GetAccessControl('Access'); $acl.AddAccessRule($rule); Set-ACL -Path C:\AWStats\logs -AclObject $acl}
		#The OLD way of doing it is as follows (using iCACLS)
		#cmd /c icacls "C:\AWStats\wwwroot" /grant "IIS AppPool\AwStats .NET v4:(OI)(CI)(RX)"
		#cmd /c icacls "C:\AWStats\wwwroot" /grant "BUILTIN\IIS_IUSRS:(OI)(CI)(RX)"
		#cmd /c icacls "C:\AWStats\wwwroot" /grant "BUILTIN\Users:(OI)(CI)(RX)"
		#cmd /c icacls "C:\AWStats\logs" /grant "NT SERVICE\TrustedInstaller:(OI)(CI)(F)"
		Restart-Service 'World Wide Web Publishing Service' -Force
		Sleep 5
		Write-Host "`t Adding the Registry Entries for AwStats" -ForegroundColor Yellow
		InstallAwStatsRegKeys | Out-Null
	}
}

####################################################################################################################################################################################
Function InstallAwStatsRegKeys()		# Function for downloading and installing AwStats
{
	if (!(Test-Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats")) {
		(New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Force) ; sleep 2
	}
	if (Test-Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats") {
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Name "DisplayName" -Value "AWStats"
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Name "UninstallString" -Value "C:\AWStats\uninstall.exe"
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Name "Publisher" -Value "Laurent Destailleur"
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Name "DisplayIcon" -Value "C:\AWStats\docs\awstats.ico"
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Name "URLInfoAbout" -Value "http://awstats.sourceforge.net"
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Name "Comments" -Value "copyright 2000/2015 Laurent Destailleur"
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Name "HelpLink" -Value "http://awstats.sourceforge.net/docs/index.html"
		New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\AWStats" -Name "URLUpdateInfo" -Value "http://awstats.sourceforge.net"
	}
}


####################################################################################################################################################################################
function CopyAndFormatXMLfile($filePath)	# Function to copy file and format the file into standard XML format so we can process it consistently
{
	[xml]$xml = Get-Content -Path "$filePath"
	# Save the file
	$xml.Save((split-path $filePath) + "\cust_" + (split-path $filePath -Leaf));
}


####################################################################################################################################################################################
Function HardenDotNET2($file)			# Function to Harden the standard security of IIS and .NET v2
{
	Get-Content $file | 
	ForEach-Object { $_ -replace '            <SecurityClass Name="EnvironmentPermission" Description="System.Security.Permissions.EnvironmentPermission, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" />', '#            <SecurityClass Name="EnvironmentPermission" Description="System.Security.Permissions.EnvironmentPermission, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" />' } | 
	ForEach-Object { $_ -replace '            <SecurityClass Name="PrintingPermission" Description="System.Drawing.Printing.PrintingPermission, System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a" />', '#            <SecurityClass Name="PrintingPermission" Description="System.Drawing.Printing.PrintingPermission, System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a" />' } | 
	ForEach-Object { $_ -replace '              <IPermission class="EnvironmentPermission" version="1" Read="TEMP;TMP;USERNAME;OS;COMPUTERNAME" />', '#              <IPermission class="EnvironmentPermission" version="1" Read="TEMP;TMP;USERNAME;OS;COMPUTERNAME" />' } | 
	ForEach-Object { $_ -replace '              <IPermission class="PrintingPermission" version="1" Level="DefaultPrinting" />', '#              <IPermission class="PrintingPermission" version="1" Level="DefaultPrinting" />' } | 
	ForEach-Object { $_ -replace '            <SecurityClass Name="ReflectionPermission" Description="System.Security.Permissions.ReflectionPermission, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" />', "            <SecurityClass Name=`"ReflectionPermission`" Description=`"System.Security.Permissions.ReflectionPermission, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089`" />`r`n            <SecurityClass Name=`"OleDbPermission`" Description=`"System.Data.OleDb.OleDbPermission, System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089`"/>" } | 
	ForEach-Object { $_ -replace '              <IPermission class="WebPermission" version="1">', '#              <IPermission class="WebPermission" version="1">' } | 
	ForEach-Object { $_ -replace '                <ConnectAccess>', '#                <ConnectAccess>' } | 
	ForEach-Object { $_ -replace '                  <URI uri="\$OriginHost\$" />', '#                  <URI uri="$OriginHost$" />' } | 
	ForEach-Object { $_ -replace '                </ConnectAccess>', '#                </ConnectAccess>' } | 
	ForEach-Object { $_ -replace '              </IPermission>', "#              </IPermission>`r`n              <IPermission class=`"WebPermission`" version=`"1`" Unrestricted=`"true`"/>" } | 
	ForEach-Object { $_ -replace "              <IPermission class=`"ReflectionPermission`" version=`"1`" Flags=`"RestrictedMemberAccess`" />", "              <IPermission class=`"ReflectionPermission`" version=`"1`" Flags=`"RestrictedMemberAccess`" />`r`n              <IPermission class=`"OleDbPermission`" version=`"1`" Unrestricted=`"true`"/>" } | 
	Set-Content ($file+".out");
	Remove-Item ($file);
	Rename-Item ($file+".out") ($file);
}


####################################################################################################################################################################################
Function HardenDotNET4($file)			# Function to Harden the standard security of IIS and .NET v4
{
	Get-Content $file | 
	ForEach-Object { $_ -replace '            <SecurityClass Name="EnvironmentPermission" Description="System.Security.Permissions.EnvironmentPermission, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" />', '#            <SecurityClass Name="EnvironmentPermission" Description="System.Security.Permissions.EnvironmentPermission, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" />' } | 
	ForEach-Object { $_ -replace '            <SecurityClass Name="PrintingPermission" Description="System.Drawing.Printing.PrintingPermission, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a" />', '#            <SecurityClass Name="PrintingPermission" Description="System.Drawing.Printing.PrintingPermission, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a" />' } | 
	ForEach-Object { $_ -replace '              <IPermission class="EnvironmentPermission" version="1" Read="TEMP;TMP;USERNAME;OS;COMPUTERNAME" />', '#              <IPermission class="EnvironmentPermission" version="1" Read="TEMP;TMP;USERNAME;OS;COMPUTERNAME" />' } | 
	ForEach-Object { $_ -replace '              <IPermission class="PrintingPermission" version="1" Level="DefaultPrinting" />', '#              <IPermission class="PrintingPermission" version="1" Level="DefaultPrinting" />' } | 
	ForEach-Object { $_ -replace '            <SecurityClass Name="ReflectionPermission" Description="System.Security.Permissions.ReflectionPermission, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" />', "            <SecurityClass Name=`"ReflectionPermission`" Description=`"System.Security.Permissions.ReflectionPermission, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089`" />`r`n            <SecurityClass Name=`"OleDbPermission`" Description=`"System.Data.OleDb.OleDbPermission, System.Data, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089`" />" } | 
	ForEach-Object { $_ -replace '              <IPermission class="ReflectionPermission" version="1" Flags="RestrictedMemberAccess" />', "              <IPermission class=`"ReflectionPermission`" version=`"1`" Flags=`"RestrictedMemberAccess`" />`r`n              <IPermission class=`"OleDbPermission`" version=`"1`" Unrestricted=`"true`" />" } | 
	Set-Content ($file+".out");
	Remove-Item ($file);
	Rename-Item ($file+".out") ($file);
}


####################################################################################################################################################################################
Function HardenDotNETapply($file)		# Function to Harden the standard security of IIS and .NET v4 - Edit the web.config file
{
	Get-Content $file | 
	ForEach-Object { $_ -replace '            <securityPolicy>', "            <securityPolicy>`r`n                <trustLevel name=`"Custom`" policyFile=`"cust_web_mediumtrust.config`" />" } |
	ForEach-Object { $_ -replace '    <location allowOverride="true">', '    <location allowOverride="false">' } |
	Set-Content ($file+".out");
	Remove-Item ($file);
	Rename-Item ($file+".out") ($file);
}


####################################################################################################################################################################################
Function FixServer2012UAC()				# Function to fix the UAC bug on Server 2012 R2 to make the server secure
{
	Write-Host "`tFixing the Server 2012 R2 UAC bug on this machine" -ForegroundColor Cyan
	# Create a local group called "Administrators File Access" on the serverif it does not exist
	CreateLocalUserOrGroup "Administrators File Access" "Local Administrators File Access - SCP Harden IIS  ********* DO NOT DELETE *********" "Group"
	# Add the Local "Administrator" to the Local Group called "Administrators File Access" unless it is already a mmember of the group
	AddLocalUserToLocalGroup "Administrators File Access" "Administrator"
	# Add the "SCPServer" User to the new group called "Administrators File Access" - This may not happen as the SolidCP Server needs to be installed first so that the user 
	#AddLocalUserToLocalGroup "Administrators File Access" "SCPServer"
	# Create the "C:\HostingSpaces" folder if it doesnt exist
	if(!(Test-Path $env:SystemDrive"\HostingSpaces")) {
		(New-Item $env:SystemDrive"\HostingSpaces" -itemType directory) | Out-Null
	}
	# Take ownership of the "C:\HostingSpaces" directory and add the "Administrators" and "Administrators File Access" Groups (Full Access) and Remove inheritance
	if(Test-Path $env:SystemDrive"\HostingSpaces") {
		# Take owenership of the "C:\HostingSpaces" folder with the "Current Logged in User Account", this should be the Administrator user
		Write-Host "`t Taking ownership of the HostingSpaces directory" -ForegroundColor Green
		Invoke-Command {takeown /F C:\HostingSpaces /R /D Y} | Out-Null;
		# Grant Full Access to the "c:\HostingSpaces" folder for the local group "Administrators"
		Write-Host "`t Granting access to the HostingSpaces directory for the Administrators group" -ForegroundColor Green
		SetAccessToFolder "C:\HostingSpaces" "Administrators" "FullControl" "Allow";
		# Grant Full Access to the "c:\HostingSpaces" folder for the local group "Administrators File Access"
		Write-Host "`t Granting access to the HostingSpaces directory for the Administrators File Access group" -ForegroundColor Green
		SetAccessToFolder "C:\HostingSpaces" "Administrators File Access" "FullControl" "Allow";
		# Disable inheritance on the "c:\HostingSpaces" folder
		Write-Host "`t Disabling Inheritance on the HostingSpaces directory" -ForegroundColor Green
		DisableFolderInheritance "C:\HostingSpaces";
		# Remove "Allow" permissions to the "C:\HostingSpaces" folder for the "Users", "CREATOR OWNER" and "SYSTEM" Groups
		Write-Host "`t Removing permissions on the HostingSpaces directory" -ForegroundColor Green
		RemoveAccessToFolder "C:\HostingSpaces" "Users" "FullControl" "Allow";
		RemoveAccessToFolderNoChk "C:\HostingSpaces" "CREATOR OWNER" "FullControl" "Allow";
		RemoveAccessToFolderNoChk "C:\HostingSpaces" "SYSTEM" "FullControl" "Allow";
		# Remove Special permissions to the "C:\HostingSpaces" folder for the "Administrator" User as it has access through the Administrators group
		RemoveAccessToFolderNoChk "C:\HostingSpaces" "Administrator" "FullControl" "Allow";
	}
	# Remove "Allow" permissions to the "C:\" drive to the "Users" Group
	Write-Host "`t Removing access to the C Drive for the Users group" -ForegroundColor Green
	RemoveAccessToFolder "C:\" "Users" "FullControl" "Allow";
	# Grant permissions for the "C:\" drive to the "Local Service" and "Network Service" Groups (Read & Execute, List Folder Contents, Read)
	Write-Host "`t Allowing access to the C Drive for the Local Service and Network Service groups" -ForegroundColor Green
	SetAccessToFolderNoChk "C:\" "LOCAL SERVICE" "ReadAndExecute" "Allow";
	SetAccessToFolderNoChk "C:\" "NETWORK SERVICE" "ReadAndExecute" "Allow";
	# Grant Full Access for the "C:\" drive for the local group "Administrators File Access"
	Write-Host "`t Allowing access to the C Drive for the Administrators File Access group" -ForegroundColor Green
	SetAccessToFolderNoChk "C:\" "Administrators File Access" "FullControl" "Allow";
	# Take ownership for *.exe files in the "C:\Windows\System32" and "C:\Windows\SysWOW64" directories (EXE Files ONLY)
	Write-Host "`t Taking ownership for all executables files in the System32 directory" -ForegroundColor Green
	Invoke-Command {takeown /A /F c:\windows\system32\*.exe} | Out-Null;
	Write-Host "`t Taking ownership for all executables files in the SysWOW64 directory" -ForegroundColor Green
	Invoke-Command {takeown /A /F c:\windows\SysWOW64\*.exe} | Out-Null;
	# Deny permissions for *.exe files in the "C:\Windows\System32" folder for the "IIS_IUSRS" Group (Deny All)
	Write-Host "`t Deny access for all executables files in the System32 directory for the IIS_IUSRS group" -ForegroundColor Green
	Invoke-Command {cacls c:\windows\system32\*.exe /E /D IIS_IUSRS} | Out-Null;
	# Deny permissions for *.exe files in the "C:\Windows\SysWOW64" folder for the "IIS_IUSRS" Group (Deny All)
	Write-Host "`t Deny access for all executables files in the SysWOW64 directory for the IIS_IUSRS group" -ForegroundColor Green
	Invoke-Command {cacls c:\windows\SysWOW64\*.exe /E /D IIS_IUSRS} | Out-Null;
}


####################################################################################################################################################################################
Function HardenDotNETforIIS()				# Function to harden .NET for IIS to make the server secure
{
	Write-Host "`tHardening IIS on this machine" -ForegroundColor Cyan
	if (!(Test-Path "C:\Windows\Microsoft.NET\Framework\v2.0.50727\CONFIG\cust_web_mediumtrust.config")) {
		# .NET v2 - Copy the files over and harden them with the above functions if they do not exist
		Write-Host "`t Hardening IIS for .NET v2" -ForegroundColor Green
		CopyAndFormatXMLfile ("C:\Windows\Microsoft.NET\Framework\v2.0.50727\CONFIG\web_mediumtrust.config")
		CopyAndFormatXMLfile ("C:\Windows\Microsoft.NET\Framework64\v2.0.50727\CONFIG\web_mediumtrust.config")
		HardenDotNET2 ("C:\Windows\Microsoft.NET\Framework\v2.0.50727\CONFIG\cust_web_mediumtrust.config")
		HardenDotNET2 ("C:\Windows\Microsoft.NET\Framework64\v2.0.50727\CONFIG\cust_web_mediumtrust.config")
		HardenDotNETapply ("C:\Windows\Microsoft.NET\Framework\v2.0.50727\CONFIG\web.config")
		HardenDotNETapply ("C:\Windows\Microsoft.NET\Framework64\v2.0.50727\CONFIG\web.config")
	}
	if (!(Test-Path "C:\Windows\Microsoft.NET\Framework\v4.0.30319\CONFIG\cust_web_mediumtrust.config")) {
		# .NET v4 - Copy the files over and harden them with the above functions if they do not exist
		Write-Host "`t Hardening IIS for .NET v4" -ForegroundColor Green
		CopyAndFormatXMLfile ("C:\Windows\Microsoft.NET\Framework\v4.0.30319\Config\web_mediumtrust.config")
		CopyAndFormatXMLfile ("C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\web_mediumtrust.config")
		HardenDotNET4 ("C:\Windows\Microsoft.NET\Framework\v4.0.30319\Config\cust_web_mediumtrust.config")
		HardenDotNET4 ("C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\cust_web_mediumtrust.config")
		HardenDotNETapply ("C:\Windows\Microsoft.NET\Framework\v4.0.30319\Config\web.config")
		HardenDotNETapply ("C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\web.config")
	}
}


####################################################################################################################################################################################
Function InstallSOlidCPInstaller()		# Function to download and install the latest SolidCP Installer from the SolidCP Website
{
	if (!(Test-Path "C:\Program Files (x86)\SolidCP Installer")) {
		# Create the SolidCP Directory in our Installation Files folder ready for downloading if it doesn't already exist
		if (!(Test-Path 'C:\_Install Files\SolidCP')) { (md -Path 'C:\_Install Files\SolidCP' -Force) | Out-Null }
		# Download the latest SolidCP Installer and save it to the "C:\_Install Files\SolidCP\" directory
		Write-Host "`tDownloading the latest SolidCP Installer" -ForegroundColor Cyan
		(New-Object System.Net.WebClient).DownloadFile("http://installer.solidcp.com/Files/stable/SolidCPInstaller.msi", "C:\_Install Files\SolidCP\SolidCPInstaller.msi")
		# Install the SolidCP Installer on this machine
		Write-Host "`tInstalling the latest SolidCP Installer on this machine" -ForegroundColor Cyan
		((Start-Process -FilePath "C:\_Install Files\SolidCP\SolidCPInstaller.msi" -ArgumentList "/qb IACCEPTSQLNCLILICENSETERMS=YES" -Wait -Passthru).ExitCode) | Out-Null
	}
}


####################################################################################################################################################################################
####################################################################################################################################################################################
# Run the SolidCP Installation Menu
SolidCPmenu

